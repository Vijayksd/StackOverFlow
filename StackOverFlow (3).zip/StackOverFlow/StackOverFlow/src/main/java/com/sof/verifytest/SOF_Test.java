package com.sof.verifytest;

import java.net.MalformedURLException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Wait;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.sof.functionality.SOF_functionality;
import com.sof.utility.BaseClassSOF;

public class SOF_Test extends BaseClassSOF {
	
	public static WebDriver chromeDriver;
	public static Wait<WebDriver> wait;
	SOF_functionality sof_Fun;
	
	@BeforeClass
	public void setUp() throws MalformedURLException, InterruptedException {
		chromeDriver = getDriver();
		BaseClassSOF.initializePageFactory(chromeDriver);
		wait = BaseClassSOF.wait;
		sof_Fun = new SOF_functionality(chromeDriver, wait);
	}
	
	@Test(priority = 1, enabled = true, description = "Verify that stack over flow page is loaded ")
	public void verifyTitle() {
		
		System.out.println("SOF page test...");
		Assert.assertTrue(sof_Fun.getPageTitle(), "SOF page - unable to search selenium webdriver");
		System.out.println("Test Case PASS : verify stack over flow page is loaded ");
		System.out.println("");
	}
	
	@Test(priority = 2, enabled = true, description = "Verify that stack over flow page is loaded and search selenium webdriver")
	public void verifySearch() {
		
		System.out.println("SOF page test...");
		Assert.assertTrue(sof_Fun.getSearch(), "SOF page - unable to search selenium webdriver");
		System.out.println("Test Case PASS : verify stack over flow page is loaded and search results shows selenium webdriver");
		System.out.println("");
	}

	@Test(priority = 3, enabled = true, description = "Verify that search results count are 15")
	public void verifyResultsCount() {
		
		System.out.println("SOF page test...");
		Assert.assertTrue(sof_Fun.getResultsCount(), "SOF page - unable to count search results");
		System.out.println("Test Case PASS : verify selenium webdriver search results count == 15");
		System.out.println("");
	}
	
	@Test(priority = 4, enabled = true, description = "Verify that search results are sorted based on votes")
	public void verifySort() {
		
		System.out.println("SOF page test...");
		Assert.assertTrue(sof_Fun.getvotesSort(), "SOF page - unable to count search results");
		System.out.println("Test Case PASS : verify search results are sorted based on votes");
		System.out.println("");
		
	}
	
	@Test(priority = 5, enabled = true, description = "Verify that search result's votes and answer count")
	public void verifyVotesandAnswerCount() {
		
		System.out.println("SOF page test...");
		Assert.assertTrue(sof_Fun.getVotesandAnswerCount(), "SOF page - unable to count search results");
		System.out.println("Test Case PASS : Verify that search result's votes and answer count");
		System.out.println("");
		
	}
	
	@Test(priority = 6, enabled = true, description = "Verify that tags except selenium-webdriver")
	public void verifytags() {
		
		System.out.println("SOF page test...");
		Assert.assertTrue(sof_Fun.getTags(), "SOF page - unable to count search results");
		System.out.println("Test Case PASS : Verify that search result's votes and answer count");
		System.out.println("");
	}
	
	@Test(priority = 7, enabled = true, description = "Verify that votes received by accepted answer.")
	public void verifyAcceptedAnsCount() throws Exception {
		
		System.out.println("SOF page test...");
		Assert.assertTrue(sof_Fun.getAcceptedAnsCount(), "SOF page - unable to count votes received by accepted answer.");
		System.out.println("Test Case PASS : Verify that votes received by accepted answer.");
		System.out.println("");
	}
	
}
