package com.sof.PageFactory;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class SOF_PF {

	@FindBy(xpath = "//div[@class='ps-relative']//input[@name='q']")
	public static WebElement search;
	
	@FindBy(xpath = "//div[@class='question-summary search-result']//a[contains(text(),'Q: ')]")
	public static List<WebElement> resultsCount;
	
	@FindBy(xpath = "//span[@class='mr2']")
	public static WebElement resultLabel;
	
	@FindBy(xpath = "//nav[@class='grid ps-relative']")
	public static WebElement moreDD;		
	
	@FindBy(xpath = "//a[contains(text(),'Votes')]")
	public static WebElement votesLink;
	
	@FindBy(xpath = "//a[@class='s-btn s-btn__muted s-btn__outlined s-btn__dropdown blr0 brr-sm js-dropdown-toggle youarehere is-selected']")
	public static WebElement votesSelected;
	
	@FindBy(xpath = "//div[@class='result-link']")
	public static List<WebElement> questionsTitle;
	
	@FindBy(xpath = "//span[@class='vote-count-post ']")
	public static List<WebElement> voteCount;
	
	@FindBy(xpath = "//div[starts-with(@class,'status answered')]//strong")
	public static List<WebElement> answersCount;
	
	@FindBy(xpath = "//a[contains(text(),'Q: ')]")
	public static List<WebElement> questionsCount;
	
	@FindBy(xpath = "//a[@class='post-tag']")
	public static List<WebElement> tags;
	
	@FindBy(xpath = "//div[@class='question-summary search-result']//div[@class='status answered-accepted']")
	public static List<WebElement> acceptdAns;
	
	@FindBy(xpath = "//div[@class='answer accepted-answer']//div[starts-with(@class,'js-vote-count grid--cell ')]")
	public static WebElement ansVoteCount;
	
	@FindBy(xpath = "//div[@class='js-accepted-answer-indicator grid--cell fc-green-500 ta-center py4']")
	public static WebElement tickPresent;
}
