package com.sof.functionality;

import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Wait;

import com.sof.PageFactory.SOF_PF;
import com.sof.utility.BaseClassSOF;

import Helpdesk.TicketsPF;

public class SOF_functionality {

	public static Wait<WebDriver> wait;
	public static WebDriver chromeDriver;
	public Actions action;
	public int count;
	boolean bool_countMatching;
	boolean bool_resultLbl;
	boolean bool_votesTab;
	boolean bool_title;
	boolean bool_votesandAnswers;
	JavascriptExecutor js;
	boolean bool_ansVotes;

	public SOF_functionality(WebDriver chromeDriver, Wait<WebDriver> wait) {
		SOF_functionality.chromeDriver = chromeDriver;
		SOF_functionality.wait = wait;
		js = BaseClassSOF.javascriptExecutor;
	}

	public boolean getPageTitle() {

		String pageTitle = chromeDriver.getTitle();
		if (pageTitle.contains("Stacks Overflow"))
			bool_title = true;

		return bool_title;

	}

	public boolean getSearch() {

		SOF_PF.search.click();
		// wait.until(ExpectedConditions.elementToBeClickable(TicketsPF.helpdeskMenu)).click();
		wait.until(ExpectedConditions.elementToBeClickable(SOF_PF.search)).sendKeys("Selenium Webdriver");
		action = new Actions(chromeDriver);
		action.sendKeys(Keys.ENTER).build().perform();

		if (SOF_PF.resultLabel.getText().contains("selenium webdriver"))
			;
		bool_resultLbl = true;

		return bool_resultLbl;

	}

	public boolean getResultsCount() {

		Iterator<WebElement> ele = SOF_PF.resultsCount.iterator();
		while (ele.hasNext()) {
			WebElement row = ele.next();
			// System.out.println("values1:"+row.getText());
			if (row.getText().startsWith("Q: ")) {
				count++;
			}
		}

		if (count == 15)
			bool_countMatching = true;

		return bool_countMatching;

	}

	public boolean getvotesSort() {

		SOF_PF.moreDD.click();
		wait.until(ExpectedConditions.elementToBeClickable(SOF_PF.votesLink)).click();

		if (wait.until(ExpectedConditions.elementToBeClickable(SOF_PF.votesSelected)).getText().equals("Votes"))
			bool_votesTab = true;

		return bool_votesTab;

	}

	public boolean getVotesandAnswerCount() {
		count = 0;
		List<WebElement> ele1 = SOF_PF.questionsTitle;
		List<WebElement> ele2 = SOF_PF.voteCount;
		List<WebElement> ele3 = SOF_PF.answersCount;

		for (int i = 0; i < ele1.size(); i++) {
			int x = ele1.size();
			WebElement quest_ee = ele1.get(i);
			WebElement vote_ee = ele2.get(i);
			// WebElement ans_ee = ele3.get(i);

			// System.out.println("test" +quest_ee.getText());
			if (quest_ee.getText().contains("Q: ")) {
				System.out.println("*************");
				System.out.println("Question Title " + (count + 1) + " : " + quest_ee.getText());
				System.out.println("Votes Count: " + vote_ee.getText());
				WebElement ans_ee = ele3.get(count);
				System.out.println("Answers Count: " + ans_ee.getText());
				System.out.println("*************");
				count++;

			}

		}

		List<WebElement> ele4 = SOF_PF.questionsCount;

		if (count == ele4.size())
			bool_votesandAnswers = true;

		return bool_votesandAnswers;
	}

	public boolean getTags() {
		try {
			System.out.println("******* Start - TAGS Except selenium-webdriver ******");
			List<WebElement> ele1 = SOF_PF.tags;
			for (int i = 0; i < ele1.size(); i++) {
				WebElement tags_ee = ele1.get(i);
				if (!(tags_ee.getText()).equalsIgnoreCase("selenium-webdriver")) {
					System.out.println(tags_ee.getText());
				}
			}
			System.out.println("******* End - TAGS Except selenium-webdriver ******");
			return true;
		} catch (Exception e) {
			System.out.println("Exception occured in method getTags: " + e);
			return false;
		}

	}

	public boolean getAcceptedAnsCount() throws Exception {

		List<WebElement> answered_ee = SOF_PF.acceptdAns;
		
		
		int answered_count = answered_ee.size();
		int count = 0;
		
		List<WebElement> ele1 = SOF_PF.resultsCount;
		boolean browserBack = false;
		for (int i = 0; i < ele1.size(); i++) {
			WebElement accept_ee = ele1.get(i);
			browserBack = false;

			js.executeScript("arguments[0].scrollIntoView(true);", accept_ee);

			wait.until(ExpectedConditions.elementToBeClickable(accept_ee)).click();

			try {
				for (int j = 0; j < 5; j++) {

					Thread.sleep(3000);
					String t = SOF_PF.tickPresent.getAttribute("aria-label");
					if (t != null && t.equals("Accepted")) {
						String AnsVoteCnt = wait.until(ExpectedConditions.visibilityOf(SOF_PF.ansVoteCount)).getText();
						System.out.println(AnsVoteCnt);
						chromeDriver.navigate().back();
						browserBack = true;
						count++;
						break;
					}

				}
				if (!browserBack) {
					chromeDriver.navigate().back();
				}

			} catch (Exception e) {
				if (!browserBack) {
					chromeDriver.navigate().back();
				}
			}
		}
		if (count == answered_count)
			bool_ansVotes = true;

		return bool_ansVotes;
	}
}